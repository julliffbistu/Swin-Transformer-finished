custom_imports = dict(imports=['r'], allow_failed_imports=False)
